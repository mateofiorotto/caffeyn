import { deleteCafeById } from '../../../services/api'



function CoffeeTable({ cafes }) {

  // Función para manejar la eliminación de un café
  const handleDelete = async (id) => {
    if (window.confirm("¿Estás seguro de eliminar este café?")) {
      try {
        await deleteCafeById(id);
        alert("Café eliminado correctamente");
        // Aquí podrías actualizar el estado o recargar los datos
      } catch (error) {
        console.error("Error al eliminar el café:", error);
        alert("No se pudo eliminar el café");
      }
    }
  };

  // Funcion para manejar la edición de un café
  const handleEdit = async (id) => {
    const newName = prompt("Ingrese el nuevo nombre del café:");
    if (newName) {
      await editCafeById(id, { name: newName });
      refreshData();
    }
  }



  return (
    <>
    <h2>Cafés</h2>
      <table className="table table-dark table-bordered">
        <thead>
          <tr className="text-center">
            <th>Nombre</th>
            <th>Tostado</th>
            <th>Nota de Sabor</th>
            <th>Origen</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>
          {cafes.map((cafe) => (
            <tr key={cafe._id}>
              <td>{cafe.name}</td>
              <td>{cafe.roastLevel}</td>
              <td>{cafe.flavorNote}</td>
              <td>{cafe.origin?.country || 'N/A'}</td>
              <td className="text-center">
                <button className="btn btn-sm btn-warning me-2">Editar</button>
                <button className="btn btn-sm btn-danger" onClick={() => handleDelete(cafe._id)}>Eliminar</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  )
}

export default CoffeeTable