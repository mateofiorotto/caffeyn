const API_URL = "http://localhost:3000/api";
/* Cafe */

// Función para obtener todos los cafés
export async function fetchCafes() {
  const res = await fetch(`${API_URL}/coffees`);
  const json = await res.json();
  console.log("Respuesta del backend:", json);
  return (await json.data) || [];
}

// Función para obtener un café por su ID
export async function fetchCafeById(id) {
  const res = await fetch(`${API_URL}/coffees/${id}`);
  const json = await res.json();
  if (!res.ok) {
    throw new Error("No se pudo obtener el café");
  }

  return (await json.data) || [];
}

// Función para borrar un café por su ID
export async function deleteCafeById(id) {
  const res = await fetch(`${API_URL}/coffees/${id}`, {
    method: "DELETE",
  });
  if (!res.ok) {
    throw new Error("No se pudo eliminar el café");
  }
  return true;
}

// Funcion para editar un café por su ID
export async function editCafeById(id, data) {
  const res = await fetch(`${API_URL}/coffees/${id}`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data),
  });
  if (!res.ok) {
    throw new Error("No se pudo editar el Café");
  }
  return true;
}

/* Orígenes */

// Función para obtener todos los orígenes
export async function fetchOrigens() {
  const res = await fetch(`${API_URL}/origins`);
  const json = await res.json();
  return (await json.data) || [];
}

// Función para obtener todos los usuarios
export async function fetchUsers() {
  const res = await fetch(`${API_URL}/users`);
  const json = await res.json();
  return (await json.data) || [];
}

// Función para obtener el perfil del usuario autenticado
export async function fetchUserProfile(token) {
  const res = await fetch(`${API_URL}/users/profile`, {
    headers: { Authorization: `Bearer ${token}` },
  });
  const json = await res.json();
  console.log("Respuesta de perfil:", json);
  return (await json.data) || null;
}
